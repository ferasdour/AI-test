-- Row Level Security (RLS) Policies for Supabase
-- Run this in Supabase SQL Editor after schema.sql

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.iocs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_iocs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- PROFILES: Everyone can read, users can update their own
CREATE POLICY "Public profiles are viewable by everyone"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- IOCs: Read access based on privacy setting
CREATE POLICY "Public IOCs are viewable by everyone"
  ON public.iocs FOR SELECT
  USING (
    is_private = false 
    OR user_id IN (
      SELECT id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can insert their own IOCs"
  ON public.iocs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own IOCs"
  ON public.iocs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own IOCs"
  ON public.iocs FOR DELETE
  USING (auth.uid() = user_id);

-- FOLLOWS: Users manage their own follows
CREATE POLICY "Users can view follows"
  ON public.follows FOR SELECT
  USING (true);

CREATE POLICY "Users can follow others"
  ON public.follows FOR INSERT
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can unfollow"
  ON public.follows FOR DELETE
  USING (auth.uid() = follower_id);

-- COMMENTS: Anyone can read, authenticated users can create
CREATE POLICY "Comments are viewable by everyone"
  ON public.comments FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create comments"
  ON public.comments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own comments"
  ON public.comments FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments"
  ON public.comments FOR DELETE
  USING (auth.uid() = user_id);

-- VOTES: Users manage their own votes
CREATE POLICY "Users can view votes"
  ON public.votes FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can vote"
  ON public.votes FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own votes"
  ON public.votes FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own votes"
  ON public.votes FOR DELETE
  USING (auth.uid() = user_id);

-- SAVED IOCs: Users manage their own saved items
CREATE POLICY "Users can view own saved IOCs"
  ON public.saved_iocs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can save IOCs"
  ON public.saved_iocs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unsave IOCs"
  ON public.saved_iocs FOR DELETE
  USING (auth.uid() = user_id);

-- REPORTS: Authenticated users can report, admins can manage
CREATE POLICY "Authenticated users can create reports"
  ON public.reports FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own reports"
  ON public.reports FOR SELECT
  USING (auth.uid() = user_id);

-- Create a function to count votes (helper for IOCs)
CREATE OR REPLACE FUNCTION get_vote_count(p_ioc_id UUID)
RETURNS TABLE(upvotes BIGINT, downvotes BIGINT) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*) FILTER (WHERE vote_type = 'upvote')::BIGINT,
    COUNT(*) FILTER (WHERE vote_type = 'downvote')::BIGINT
  FROM public.votes
  WHERE ioc_id = p_ioc_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
