@echo off
REM Supabase Setup Script for Windows
REM This script helps initialize and configure Supabase for the IOC sharing platform

echo === IOC Share Platform - Supabase Setup ===
echo.

REM Check if Supabase CLI is installed
where supabase >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Error: Supabase CLI is not installed.
    echo Install it with: npm install -g supabase
    echo Or download from: https://github.com/supabase/cli
    exit /b 1
)

REM Check for project reference
if "%SUPABASE_PROJECT_REF%"=="" (
    echo Warning: SUPABASE_PROJECT_REF environment variable not set
    echo Enter your Supabase project reference:
    set /p SUPABASE_PROJECT_REF=
)

echo Setting up Supabase...

REM Link to Supabase project
echo Linking to Supabase project...
supabase link --project-ref %SUPABASE_PROJECT_REF% --no-interactive

REM Push schema to remote
echo Pushing database schema...
supabase db push

echo.
echo Setup complete!
echo.
echo Next steps:
echo 1. Go to Supabase Dashboard ^> Authentication ^> Providers
echo 2. Enable GitHub OAuth provider
echo 3. Add your OAuth callback URL to GitHub OAuth App
echo 4. Update assets/js/config.js with your Supabase credentials
echo.
echo To start local development: supabase start
