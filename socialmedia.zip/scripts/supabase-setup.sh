#!/bin/bash

# Supabase Setup Script
# This script helps initialize and configure Supabase for the IOC sharing platform

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== IOC Share Platform - Supabase Setup ===${NC}\n"

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null; then
    echo -e "${RED}Error: Supabase CLI is not installed.${NC}"
    echo "Install it with: npm install -g supabase"
    echo "Or via: https://github.com/supabase/cli"
    exit 1
fi

# Check for required environment variables
if [ -z "$SUPABASE_PROJECT_REF" ]; then
    echo -e "${YELLOW}Warning: SUPABASE_PROJECT_REF not set${NC}"
    echo "Enter your Supabase project reference (found in dashboard URL):"
    read -r SUPABASE_PROJECT_REF
fi

echo "Setting up Supabase..."

# Link to local project (optional - for local development)
echo "Linking to Supabase project..."
supabase link --project-ref "$SUPABASE_PROJECT_REF" --no-interactive

# Push schema to remote
echo "Pushing database schema..."
supabase db push

echo -e "\n${GREEN}Setup complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Go to Supabase Dashboard > Authentication > Providers"
echo "2. Enable GitHub OAuth provider"
echo "3. Add your OAuth callback URL to GitHub OAuth App"
echo "4. Update assets/js/config.js with your Supabase credentials"
echo ""
echo "To start local development: supabase start"
