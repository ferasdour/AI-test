# IOC Share - Threat Intelligence Community Platform

A minimal-cost, social-media style platform for security researchers to share and discuss Indicators of Compromise (IOCs).

## Architecture

- **Frontend**: Static HTML/CSS/JS hosted on GitHub Pages
- **Backend**: Supabase (PostgreSQL database + REST API + Authentication)
- **Deployment**: GitHub Actions for automatic deployment

## Features

- Social feed displaying latest IOCs
- Multiple IOC types: IPv4/IPv6, Domains, URLs, Hashes (MD5/SHA1/SHA256), Emails, CVEs, and more
- User authentication (email/password + GitHub OAuth)
- Upvote/downvote system
- Save/bookmark IOCs
- Comment on IOCs
- Follow other researchers
- Filter by IOC type
- Search functionality
- Private IOC sharing option

## Prerequisites

1. GitHub account
2. Node.js 18+ (for Supabase CLI)
3. Supabase account (free tier)

## Quick Start

### Step 1: Create GitHub Repository

1. Go to GitHub and create a new repository
2. Clone this repository or copy all files to your new repo
3. Enable GitHub Pages: Settings > Pages > Source: Deploy from branch > main

### Step 2: Set Up Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. Note your project URL and anon key (Settings > API)
3. Go to SQL Editor in Supabase dashboard
4. Copy and run the contents of `supabase/schema.sql`
5. Copy and run the contents of `supabase/rlspolicies.sql`

### Step 3: Configure Authentication

1. In Supabase Dashboard: Authentication > Providers
2. Enable **Email** provider (or configure GitHub OAuth)
3. For GitHub OAuth:
   - Create OAuth App in GitHub (Settings > Developer settings > OAuth Apps)
   - Add callback URL: `https://[your-project].supabase.co/auth/v1/callback`
   - Copy Client ID and Secret to Supabase

### Step 4: Configure Frontend

1. Edit `assets/js/config.js`
2. Update the following values:
   ```javascript
   const CONFIG = {
       SUPABASE_URL: 'https://your-project.supabase.co',
       SUPABASE_ANON_KEY: 'your-anon-key',
       GITHUB_CLIENT_ID: 'your-github-client-id',
       SITE_URL: 'https://yourusername.github.io'
   };
   ```

### Step 5: Deploy

1. Push your changes to GitHub
2. Go to Actions tab
3. Watch the deployment workflow run
4. Your site will be live at `https://yourusername.github.io`

## Supabase Setup Script

Alternatively, use the Supabase CLI:

```bash
# Install Supabase CLI
npm install -g supabase

# Set environment variable
export SUPABASE_PROJECT_REF=your-project-ref

# Run setup script
./scripts/supabase-setup.sh
```

Or on Windows:
```cmd
set SUPABASE_PROJECT_REF=your-project-ref
scripts\supabase-setup.bat
```

## Database Schema

### Tables

- **profiles**: User profiles (extends auth.users)
- **iocs**: IOC submissions
- **follows**: User follow relationships
- **comments**: IOC comments
- **votes**: Upvote/downvote tracking
- **saved_iocs**: Bookmarked IOCs
- **reports**: Content flagging

### Security

Row Level Security (RLS) policies are configured to:
- Allow public read access to non-private IOCs
- Require authentication for creating content
- Users can only modify their own content

## Cost Estimation

- **GitHub Pages**: Free (for public repos)
- **Supabase Free Tier**:
  - Up to 500MB database
  - 1GB file storage
  - 50MB bandwidth/month
  - 50,000 monthly active users

**Total cost: $0/month** (for small to medium usage)

## Project Structure

```
socialmedia/
├── .github/
│   └── workflows/
│       └── deploy.yml          # GitHub Pages deployment
├── assets/
│   ├── css/
│   │   └── styles.css          # Main stylesheet
│   ├── js/
│   │   ├── config.js           # Configuration template
│   │   └── app.js              # Main application
│   └── images/
│       └── default-avatar.png  # Default avatar
├── supabase/
│   ├── schema.sql              # Database schema
│   ├── rlspolicies.sql         # Security policies
│   ├── config.json             # Config template
│   └── setup scripts
├── scripts/
│   ├── supabase-setup.sh       # Linux/Mac setup
│   └── supabase-setup.bat      # Windows setup
├── index.html                  # Main page
└── README.md                   # This file
```

## Development

To run locally:

1. Install dependencies:
   ```bash
   npm install -g supabase
   ```

2. Start local Supabase:
   ```bash
   supabase start
   ```

3. Use a local server:
   ```bash
   npx serve .
   ```

## Security Considerations

1. **Never commit secrets**: Keep your config.js values secure
2. **Use environment variables** in production
3. **Enable 2FA** on Supabase and GitHub
4. **Review RLS policies** regularly
5. **Monitor API usage** in Supabase dashboard
6. **Validate IOCs** on client and server side

## License

MIT License - Feel free to use and modify for your community.
