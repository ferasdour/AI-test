// Configuration template - Copy this to config.js and fill in your values

const CONFIG = {
    SUPABASE_URL: 'YOUR_SUPABASE_URL',
    SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY',
    
    // GitHub OAuth configuration (optional)
    GITHUB_CLIENT_ID: 'YOUR_GITHUB_CLIENT_ID',
    
    // Site configuration
    SITE_NAME: 'IOC Share',
    SITE_URL: 'https://yourusername.github.io',
    
    // Pagination
    PAGE_SIZE: 20
};

// IOC Type icons for display
const IOC_TYPE_ICONS = {
    ipv4: 'fa-network-wired',
    ipv6: 'fa-network-wired',
    domain: 'fa-domain',
    url: 'fa-link',
    md5: 'fa-fingerprint',
    sha1: 'fa-fingerprint',
    sha256: 'fa-fingerprint',
    email: 'fa-envelope',
    cve: 'fa-bug',
    mutex: 'fa-lock',
    file_path: 'fa-folder',
    registry: 'fa-database',
    btc_address: 'fa-bitcoin',
    wallet_address: 'fa-wallet'
};
