// IOC Share - Main Application JavaScript

class IOCShareApp {
    constructor() {
        this.supabase = null;
        this.currentUser = null;
        this.currentFilter = { type: 'all', sort: 'newest' };
        this.iocs = [];
        this.page = 0;
        this.init();
    }

    async init() {
        this.initSupabase();
        this.bindEvents();
        this.checkAuth();
        await this.loadStats();
        await this.loadIOCs();
    }

    initSupabase() {
        if (typeof CONFIG === 'undefined' || !CONFIG.SUPABASE_URL || !CONFIG.SUPABASE_ANON_KEY) {
            console.warn('Supabase configuration missing. Please update assets/js/config.js');
            return;
        }

        this.supabase = window.supabase.createClient(
            CONFIG.SUPABASE_URL,
            CONFIG.SUPABASE_ANON_KEY
        );
    }

    bindEvents() {
        document.getElementById('loginBtn')?.addEventListener('click', () => this.showAuthModal('login'));
        document.getElementById('signupBtn')?.addEventListener('click', () => this.showAuthModal('signup'));
        document.getElementById('logoutBtn')?.addEventListener('click', () => this.logout());
        document.getElementById('loginForm')?.addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('signupForm')?.addEventListener('submit', (e) => this.handleSignup(e));
        document.getElementById('githubLogin')?.addEventListener('click', () => this.loginWithGitHub());
        
        document.querySelectorAll('.auth-tab').forEach(tab => {
            tab.addEventListener('click', (e) => this.switchAuthTab(e.target.dataset.tab));
        });
        
        document.getElementById('closeAuthModal')?.addEventListener('click', () => this.hideAuthModal());
        document.getElementById('newIocBtn')?.addEventListener('click', () => this.showIocForm());
        document.getElementById('cancelIoc')?.addEventListener('click', () => this.hideIocForm());
        document.getElementById('iocFormElement')?.addEventListener('submit', (e) => this.handleIocSubmit(e));
        
        document.querySelectorAll('#iocTypeFilters li').forEach(item => {
            item.addEventListener('click', () => this.filterByType(item.dataset.type));
        });
        
        document.getElementById('sortSelect')?.addEventListener('change', (e) => this.changeSort(e.target.value));
        document.getElementById('loadMoreBtn')?.addEventListener('click', () => this.loadMore());
        
        document.getElementById('searchInput')?.addEventListener('keyup', (e) => {
            if (e.key === 'Enter') this.search(e.target.value);
        });
        
        document.getElementById('userAvatar')?.addEventListener('click', (e) => {
            e.stopPropagation();
            document.querySelector('.dropdown-menu')?.classList.toggle('show');
        });
        
        document.addEventListener('click', () => {
            document.querySelector('.dropdown-menu')?.classList.remove('show');
        });
        
        document.getElementById('authModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'authModal') this.hideAuthModal();
        });
        
        document.getElementById('iocDetailModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'iocDetailModal') this.hideIocDetail();
        });
    }

    async checkAuth() {
        if (!this.supabase) return;

        const { data: { session } } = await this.supabase.auth.getSession();
        
        if (session) {
            this.currentUser = session.user;
            this.updateAuthUI(true);
        }

        this.supabase.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_IN' && session) {
                this.currentUser = session.user;
                this.updateAuthUI(true);
            } else if (event === 'SIGNED_OUT') {
                this.currentUser = null;
                this.updateAuthUI(false);
            }
        });
    }

    updateAuthUI(isLoggedIn) {
        const authSection = document.getElementById('authSection');
        const userSection = document.getElementById('userSection');
        const newIocBtn = document.getElementById('newIocBtn');
        
        if (isLoggedIn) {
            authSection?.classList.add('hidden');
            userSection?.classList.remove('hidden');
            newIocBtn?.classList.remove('hidden');
        } else {
            authSection?.classList.remove('hidden');
            userSection?.classList.add('hidden');
            newIocBtn?.classList.add('hidden');
        }
    }

    showAuthModal(tab = 'login') {
        document.getElementById('authModal').classList.remove('hidden');
        this.switchAuthTab(tab);
    }

    hideAuthModal() {
        document.getElementById('authModal').classList.add('hidden');
    }

    switchAuthTab(tab) {
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`.auth-tab[data-tab="${tab}"]`)?.classList.add('active');
        
        document.getElementById('loginForm').classList.toggle('hidden', tab !== 'login');
        document.getElementById('signupForm').classList.toggle('hidden', tab !== 'signup');
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        try {
            const { error } = await this.supabase.auth.signInWithPassword({ email, password });
            if (error) throw error;
            this.hideAuthModal();
            this.showToast('Successfully signed in!', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    async handleSignup(e) {
        e.preventDefault();
        
        const username = document.getElementById('signupUsername').value;
        const email = document.getElementById('signupEmail').value;
        const password = document.getElementById('signupPassword').value;
        
        try {
            const { error } = await this.supabase.auth.signUp({
                email,
                password,
                options: { data: { username } }
            });
            if (error) throw error;
            this.hideAuthModal();
            this.showToast('Check your email to confirm signup!', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    async loginWithGitHub() {
        try {
            const { error } = await this.supabase.auth.signInWithOAuth({
                provider: 'github',
                options: { redirectTo: `${CONFIG.SITE_URL}/index.html` }
            });
            if (error) throw error;
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    async logout() {
        try {
            await this.supabase.auth.signOut();
            this.showToast('Successfully signed out', 'success');
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    showIocForm() {
        if (!this.currentUser) {
            this.showAuthModal();
            return;
        }
        document.getElementById('iocForm').classList.remove('hidden');
    }

    hideIocForm() {
        document.getElementById('iocForm').classList.add('hidden');
        document.getElementById('iocFormElement').reset();
    }

    async handleIocSubmit(e) {
        e.preventDefault();
        
        if (!this.currentUser) {
            this.showToast('Please sign in to share IOCs', 'error');
            return;
        }

        const iocData = {
            user_id: this.currentUser.id,
            ioc_type: document.getElementById('iocType').value,
            ioc_value: document.getElementById('iocValue').value.trim(),
            title: document.getElementById('iocTitle').value.trim(),
            description: document.getElementById('iocDescription').value.trim(),
            tags: document.getElementById('iocTags').value.split(',').map(t => t.trim()).filter(Boolean),
            is_private: document.getElementById('iocPrivate').checked
        };

        try {
            const { error } = await this.supabase.from('iocs').insert(iocData);
            if (error) throw error;
            this.hideIocForm();
            this.showToast('IOC shared successfully!', 'success');
            await this.loadIOCs();
        } catch (error) {
            this.showToast(error.message, 'error');
        }
    }

    async loadIOCs(reset = true) {
        if (reset) {
            this.page = 0;
            this.iocs = [];
        }

        if (!this.supabase) {
            this.renderDemoIOCs();
            return;
        }

        let query = this.supabase
            .from('iocs')
            .select(`*, profiles:user_id (username, display_name, avatar_url)`)
            .eq('is_private', false);

        if (this.currentFilter.type !== 'all') {
            query = query.eq('ioc_type', this.currentFilter.type);
        }

        switch (this.currentFilter.sort) {
            case 'popular':
                query = query.order('upvote_count', { ascending: false });
                break;
            case 'discussed':
                query = query.order('created_at', { ascending: false });
                break;
            default:
                query = query.order('created_at', { ascending: false });
        }

        query = query.range(this.page * CONFIG.PAGE_SIZE, (this.page + 1) * CONFIG.PAGE_SIZE - 1);
        const { data, error } = await query;

        if (error) {
            console.error('Error loading IOCs:', error);
            return;
        }

        this.iocs = reset ? data : [...this.iocs, ...data];
        this.renderIOCs();
    }

    renderDemoIOCs() {
        const demoIOCs = [
            {
                id: '1',
                ioc_type: 'domain',
                ioc_value: 'malicious-domain.example.com',
                title: 'Cobalt Strike C2 Server',
                description: 'Threat actor using this domain for Cobalt Strike beacon communications. First seen in recent APT29 campaign.',
                tags: ['APT29', 'CobaltStrike', 'C2'],
                created_at: new Date().toISOString(),
                upvote_count: 42,
                view_count: 156,
                profiles: { username: 'threat_hunter', display_name: 'Threat Hunter', avatar_url: null }
            },
            {
                id: '2',
                ioc_type: 'sha256',
                ioc_value: 'a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456',
                title: 'Emotet Dropper Sample',
                description: 'SHA256 hash of Emotet dropper binary. VT score: 62/70. Password for archive: infected',
                tags: ['Emotet', 'Malware', 'Dropper'],
                created_at: new Date(Date.now() - 3600000).toISOString(),
                upvote_count: 28,
                view_count: 89,
                profiles: { username: 'malware_researcher', display_name: 'Malware Researcher', avatar_url: null }
            },
            {
                id: '3',
                ioc_type: 'ipv4',
                ioc_value: '192.168.1.100',
                title: 'Suspicious Callback Address',
                description: 'IP address observed making suspicious outbound connections to known malicious infrastructure.',
                tags: ['Ransomware', 'Network'],
                created_at: new Date(Date.now() - 7200000).toISOString(),
                upvote_count: 15,
                view_count: 45,
                profiles: { username: 'soc_analyst', display_name: 'SOC Analyst', avatar_url: null }
            },
            {
                id: '4',
                ioc_type: 'cve',
                ioc_value: 'CVE-2024-12345',
                title: 'Critical Vulnerability in Enterprise Software',
                description: 'Recently disclosed vulnerability. PoC available. Recommend immediate patching.',
                tags: ['Vulnerability', '0-day', 'Patching'],
                created_at: new Date(Date.now() - 86400000).toISOString(),
                upvote_count: 67,
                view_count: 234,
                profiles: { username: 'vuln_researcher', display_name: 'Vulnerability Researcher', avatar_url: null }
            }
        ];

        this.iocs = demoIOCs;
        this.renderIOCs();
    }

    renderIOCs() {
        const feed = document.getElementById('iocFeed');
        
        if (this.iocs.length === 0) {
            const div = document.createElement('div');
            div.className = 'loading';
            div.textContent = 'No IOCs found. Be the first to share!';
            feed.textContent = '';
            feed.appendChild(div);
            return;
        }

        feed.textContent = '';
        
        this.iocs.forEach(ioc => {
            const card = this.createIOCCard(ioc);
            feed.appendChild(card);
        });

        feed.querySelectorAll('.ioc-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.ioc-action')) {
                    this.showIocDetail(card.dataset.id);
                }
            });
        });

        this.bindIOCActions();
    }

    createIOCCard(ioc) {
        const card = document.createElement('div');
        card.className = 'ioc-card';
        card.dataset.id = ioc.id;

        const profile = ioc.profiles || {};
        const username = profile.username || '';
        const avatarUrl = profile.avatar_url || 'assets/images/default-avatar.png';
        const timeAgo = this.getTimeAgo(ioc.created_at);
        const iocType = ioc.ioc_type;
        const title = ioc.title;
        const iocValue = ioc.ioc_value;
        const description = ioc.description;

        const header = document.createElement('div');
        header.className = 'ioc-header';

        const authorDiv = document.createElement('div');
        authorDiv.className = 'ioc-author';

        const img = document.createElement('img');
        img.src = avatarUrl;
        img.alt = username;

        const authorInfo = document.createElement('div');
        authorInfo.className = 'author-info';

        const authorName = document.createElement('span');
        authorName.className = 'author-name';
        authorName.textContent = '@' + username;

        const authorMeta = document.createElement('span');
        authorMeta.className = 'author-meta';
        authorMeta.textContent = timeAgo;

        authorInfo.appendChild(authorName);
        authorInfo.appendChild(authorMeta);
        authorDiv.appendChild(img);
        authorDiv.appendChild(authorInfo);

        const badge = document.createElement('span');
        badge.className = 'ioc-type-badge ' + iocType;
        badge.textContent = iocType;

        header.appendChild(authorDiv);
        header.appendChild(badge);
        card.appendChild(header);

        const titleEl = document.createElement('h3');
        titleEl.className = 'ioc-title';
        titleEl.textContent = title;
        card.appendChild(titleEl);

        const valueDiv = document.createElement('div');
        valueDiv.className = 'ioc-value';

        const valueSpan = document.createElement('span');
        valueSpan.textContent = iocValue;

        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-btn';
        copyBtn.dataset.value = iocValue;
        copyBtn.title = 'Copy';
        copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i>';

        valueDiv.appendChild(valueSpan);
        valueDiv.appendChild(copyBtn);
        card.appendChild(valueDiv);

        if (description) {
            const descP = document.createElement('p');
            descP.className = 'ioc-description';
            descP.textContent = description;
            card.appendChild(descP);
        }

        if (ioc.tags && ioc.tags.length > 0) {
            const tagsDiv = document.createElement('div');
            tagsDiv.className = 'ioc-tags';
            ioc.tags.forEach(tag => {
                const span = document.createElement('span');
                span.className = 'tag';
                span.textContent = '#' + tag;
                tagsDiv.appendChild(span);
            });
            card.appendChild(tagsDiv);
        }

        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'ioc-actions';

        const voteUpBtn = document.createElement('button');
        voteUpBtn.className = 'ioc-action vote-btn';
        voteUpBtn.dataset.id = ioc.id;
        voteUpBtn.dataset.type = 'upvote';
        voteUpBtn.innerHTML = '<i class="fa-regular fa-thumbs-up"></i>';
        const voteUpSpan = document.createElement('span');
        voteUpSpan.textContent = String(ioc.upvote_count || 0);
        voteUpBtn.appendChild(voteUpSpan);

        const voteDownBtn = document.createElement('button');
        voteDownBtn.className = 'ioc-action vote-btn';
        voteDownBtn.dataset.id = ioc.id;
        voteDownBtn.dataset.type = 'downvote';
        voteDownBtn.innerHTML = '<i class="fa-regular fa-thumbs-down"></i>';

        const saveBtn = document.createElement('button');
        saveBtn.className = 'ioc-action save-btn';
        saveBtn.dataset.id = ioc.id;
        saveBtn.innerHTML = '<i class="fa-regular fa-bookmark"></i><span>Save</span>';

        const shareBtn = document.createElement('button');
        shareBtn.className = 'ioc-action share-btn';
        shareBtn.dataset.id = ioc.id;
        shareBtn.innerHTML = '<i class="fa-solid fa-share-nodes"></i><span>Share</span>';

        actionsDiv.appendChild(voteUpBtn);
        actionsDiv.appendChild(voteDownBtn);
        actionsDiv.appendChild(saveBtn);
        actionsDiv.appendChild(shareBtn);
        card.appendChild(actionsDiv);

        return card;
    }

    bindIOCActions() {
        document.querySelectorAll('.ioc-value .copy-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(btn.dataset.value);
                this.showToast('Copied to clipboard!', 'success');
            });
        });

        document.querySelectorAll('.vote-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (!this.currentUser) {
                    this.showAuthModal();
                    return;
                }
                this.handleVote(btn.dataset.id, btn.dataset.type);
            });
        });

        document.querySelectorAll('.save-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (!this.currentUser) {
                    this.showAuthModal();
                    return;
                }
                this.handleSave(btn.dataset.id);
            });
        });
    }

    async handleVote(iocId, voteType) {
        try {
            const { data: existingVote } = await this.supabase
                .from('votes')
                .select('*')
                .eq('ioc_id', iocId)
                .eq('user_id', this.currentUser.id)
                .single();

            if (existingVote) {
                if (existingVote.vote_type === voteType) {
                    await this.supabase.from('votes').delete().eq('id', existingVote.id);
                } else {
                    await this.supabase.from('votes').update({ vote_type: voteType }).eq('id', existingVote.id);
                }
            } else {
                await this.supabase.from('votes').insert({
                    ioc_id: iocId,
                    user_id: this.currentUser.id,
                    vote_type: voteType
                });
            }

            await this.loadIOCs();
        } catch (error) {
            this.showToast('Error processing vote', 'error');
        }
    }

    async handleSave(iocId) {
        try {
            const { error } = await this.supabase.from('saved_iocs').insert({
                ioc_id: iocId,
                user_id: this.currentUser.id
            });

            if (error && !error.message.includes('duplicate')) {
                throw error;
            }

            this.showToast('IOC saved!', 'success');
        } catch (error) {
            this.showToast('Error saving IOC', 'error');
        }
    }

    async loadMore() {
        this.page++;
        await this.loadIOCs(false);
    }

    filterByType(type) {
        document.querySelectorAll('#iocTypeFilters li').forEach(li => li.classList.remove('active'));
        document.querySelector(`#iocTypeFilters li[data-type="${type}"]`)?.classList.add('active');
        
        this.currentFilter.type = type;
        document.getElementById('feedTitle').textContent = type === 'all' ? 'Latest IOCs' : `${type.toUpperCase()} IOCs`;
        
        this.loadIOCs();
    }

    changeSort(sort) {
        this.currentFilter.sort = sort;
        this.loadIOCs();
    }

    search(query) {
        console.log('Searching for:', query);
    }

    async loadStats() {
        if (!this.supabase) {
            document.getElementById('totalIocs').textContent = '1,234';
            document.getElementById('totalUsers').textContent = '567';
            return;
        }

        const [iocCount, userCount] = await Promise.all([
            this.supabase.from('iocs').select('*', { count: 'exact', head: true }),
            this.supabase.from('profiles').select('*', { count: 'exact', head: true })
        ]);

        document.getElementById('totalIocs').textContent = iocCount.count?.toLocaleString() || '0';
        document.getElementById('totalUsers').textContent = userCount.count?.toLocaleString() || '0';
    }

    showIocDetail(iocId) {
        const ioc = this.iocs.find(i => i.id === iocId);
        if (!ioc) return;

        const detail = document.getElementById('iocDetail');
        detail.textContent = '';

        const profile = ioc.profiles || {};
        const header = document.createElement('div');
        header.className = 'ioc-detail-header';
        
        const badge = document.createElement('span');
        badge.className = `ioc-type-badge ${this.escapeHtml(ioc.ioc_type)} ioc-detail-type`;
        badge.textContent = ioc.ioc_type;
        
        const title = document.createElement('h2');
        title.textContent = ioc.title;

        header.appendChild(badge);
        header.appendChild(title);
        detail.appendChild(header);

        const valueDiv = document.createElement('div');
        valueDiv.className = 'ioc-detail-value';
        
        const valueSpan = document.createElement('span');
        valueSpan.textContent = ioc.ioc_value;
        
        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-btn';
        copyBtn.dataset.value = ioc.ioc_value;
        copyBtn.title = 'Copy';
        copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i>';
        
        valueDiv.appendChild(valueSpan);
        valueDiv.appendChild(copyBtn);
        detail.appendChild(valueDiv);

        if (ioc.description) {
            const descP = document.createElement('p');
            descP.className = 'ioc-detail-description';
            descP.textContent = ioc.description;
            detail.appendChild(descP);
        }

        const authorDiv = document.createElement('div');
        authorDiv.className = 'ioc-author';
        authorDiv.style.marginTop = '1rem';
        
        const img = document.createElement('img');
        img.src = profile.avatar_url || 'assets/images/default-avatar.png';
        img.alt = profile.username || '';
        
        const authorInfo = document.createElement('div');
        authorInfo.className = 'author-info';
        
        const authorName = document.createElement('span');
        authorName.className = 'author-name';
        authorName.textContent = '@' + (profile.username || '');
        
        const authorMeta = document.createElement('span');
        authorMeta.className = 'author-meta';
        authorMeta.textContent = this.getTimeAgo(ioc.created_at);
        
        authorInfo.appendChild(authorName);
        authorInfo.appendChild(authorMeta);
        authorDiv.appendChild(img);
        authorDiv.appendChild(authorInfo);
        detail.appendChild(authorDiv);

        if (ioc.tags && ioc.tags.length > 0) {
            const tagsDiv = document.createElement('div');
            tagsDiv.className = 'ioc-tags';
            tagsDiv.style.marginTop = '1rem';
            ioc.tags.forEach(tag => {
                const span = document.createElement('span');
                span.className = 'tag';
                span.textContent = '#' + tag;
                tagsDiv.appendChild(span);
            });
            detail.appendChild(tagsDiv);
        }

        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(ioc.ioc_value);
            this.showToast('Copied to clipboard!', 'success');
        });

        document.getElementById('iocDetailModal').classList.remove('hidden');
        this.loadComments(iocId);
    }

    hideIocDetail() {
        document.getElementById('iocDetailModal').classList.add('hidden');
    }

    async loadComments(iocId) {
        const commentsList = document.getElementById('commentsList');
        
        if (!this.supabase) {
            commentsList.textContent = '';
            const p = document.createElement('p');
            p.style.color = 'var(--text-muted)';
            p.textContent = 'Demo: Comments would load here';
            commentsList.appendChild(p);
            return;
        }

        const { data } = await this.supabase
            .from('comments')
            .select(`*, profiles:user_id (username, display_name, avatar_url)`)
            .eq('ioc_id', iocId)
            .order('created_at', { ascending: true });

        commentsList.textContent = '';
        
        if (!data || data.length === 0) {
            const p = document.createElement('p');
            p.style.color = 'var(--text-muted)';
            p.textContent = 'No comments yet. Be the first to comment!';
            commentsList.appendChild(p);
            return;
        }

        data.forEach(comment => {
            const profile = comment.profiles || {};
            const commentDiv = document.createElement('div');
            commentDiv.className = 'comment';
            
            const img = document.createElement('img');
            img.src = profile.avatar_url || 'assets/images/default-avatar.png';
            img.alt = profile.username || '';
            
            const bodyDiv = document.createElement('div');
            bodyDiv.className = 'comment-body';
            
            const headerDiv = document.createElement('div');
            headerDiv.className = 'comment-header';
            
            const authorSpan = document.createElement('span');
            authorSpan.className = 'comment-author';
            authorSpan.textContent = '@' + (profile.username || '');
            
            const timeSpan = document.createElement('span');
            timeSpan.className = 'comment-time';
            timeSpan.textContent = this.getTimeAgo(comment.created_at);
            
            headerDiv.appendChild(authorSpan);
            headerDiv.appendChild(timeSpan);
            
            const textP = document.createElement('p');
            textP.className = 'comment-text';
            textP.textContent = comment.content;
            
            bodyDiv.appendChild(headerDiv);
            bodyDiv.appendChild(textP);
            commentDiv.appendChild(img);
            commentDiv.appendChild(bodyDiv);
            commentsList.appendChild(commentDiv);
        });
    }

    getTimeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const seconds = Math.floor((now - date) / 1000);

        if (seconds < 60) return 'just now';
        if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
        if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
        if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
        
        return date.toLocaleDateString();
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new IOCShareApp();
});
